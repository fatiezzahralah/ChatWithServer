module com.example.controlebb {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.ChatWithServer to javafx.fxml;
    exports com.example.ChatWithServer;
}