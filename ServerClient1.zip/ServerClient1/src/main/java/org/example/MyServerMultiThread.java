package org.example;

import javax.sql.XAConnection;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class MyServerMultiThread extends  Thread{
    private int ClientNumber;
    public static void main(String[] args){
        new MyServerMultiThread().start();
    }
    @Override
    public void run(){
        try {
            ServerSocket ss=new ServerSocket(1234);
            System.out.println("le serveur essaie de  demarrer");
            while (true){
                Socket s = ss.accept();
                ++ClientNumber;
                new Communication(s,ClientNumber).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //classe interne
    public class Communication extends Thread{
        private Socket s;
        private int ClientNumber;
         Communication(Socket s ,int ClientNumber){
            this.s=s;
            this.ClientNumber=ClientNumber;

        }
        @Override
        public void run(){
            try {
                InputStream is=s.getInputStream();
                InputStreamReader isr=new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                OutputStream os= s.getOutputStream();
                String Ip=s.getRemoteSocketAddress().toString();
                System.out.println("le client numero " +ClientNumber +" et son ip"+Ip);
                PrintWriter pw=new PrintWriter(os,true);
                while (true){
                    String UserRequest= br.readLine();
                    pw.println("la taille de votre chaine est"+UserRequest.length());
                }

            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }

    }
}
