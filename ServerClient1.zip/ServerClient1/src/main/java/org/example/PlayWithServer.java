package org.example;

import javax.sql.XAConnection;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.IllegalFormatException;
import java.util.Random;
import java.util.Scanner;

public class PlayWithServer extends  Thread{
    private int ClientNumber;
    private  int SecretNbre;
    private boolean fin;
    private String Winner;
    public static void main(String[] args){

        new PlayWithServer().start();
    }
    @Override
    public void run(){
        try {
            ServerSocket ss=new ServerSocket(123);
            SecretNbre=new Random().nextInt(100);
            System.out.println("le serveur essaie de  demarrer");
            while (true){
                Socket s = ss.accept();
                ++ClientNumber;
                new Communication(s,ClientNumber).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    //classe interne
    public class Communication extends Thread {
        private Socket s;
        private int ClientNumber;

        Communication(Socket s, int ClientNumber) {
            this.s = s;
            this.ClientNumber = ClientNumber;

        }

        @Override
        public void run() {
            try {
                InputStream is = s.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);
                OutputStream os = s.getOutputStream();
                String Ip = s.getRemoteSocketAddress().toString();
                System.out.println("le client numero " + ClientNumber + " et son ip" + Ip);
                PrintWriter pw = new PrintWriter(os, true);
                pw.println(("Vous etes le client: " + ClientNumber));
                pw.println("Devinez le nombre secret... :D");
                while (true) {
                    String UserRequest = br.readLine();
                    boolean RequestFormat = false;
                    int UserNbre = 0;
                    try {
                        UserNbre = Integer.parseInt(UserRequest);

                        RequestFormat = true;
                    } catch (NumberFormatException e) {
                        pw.println("raa9em machi jomlaa!!");
                    }
                    if (RequestFormat = true) {

                        System.out.println("le client " + ClientNumber + "A envoye le nbr" +UserNbre);

                        if (!fin) {
                            if (UserNbre > SecretNbre) pw.println("Votre nombre est supperieur au secret number");
                            else if (UserNbre < SecretNbre) pw.println("Votre nombre est inferieur au secret number");
                            else {
                                pw.println("bien jouer");
                                System.out.println("le  gagnant est le client numero " + ClientNumber + " et son ip" + Ip);
                                fin = true;
                            }
                        } else {
                            pw.println("fin de jeu le gagnant est " + ClientNumber);
                        }


                        pw.println("la taille de votre chaine est" + UserRequest.length());
                    }

                }




            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }
}